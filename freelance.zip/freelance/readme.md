## Laravel Admin - a scaffold admin framework for laravel

I will be updating the documentation near soon.

## Installation

1. clone the repo
2. From project folder's root terminal, run "composer install"
3. Set database credentials in ".env" file
4. Run "php artisan migrate"
5. Run "php artisan db:seed"
6. Run "php artisan serve"
7. Now type "http://localhost:8000" you can see the front end there.
8. Admin Panel Login "http://localhost:8000/admin" will redirect you to login page.
9. User Name : "user@admin.com" Password : "ReM1@Et$"
10. Admin User Name : "admin@admin.com"  Password : "1Ade$Er32"

Still need to do a lot of things, I will be updating soon.

## Contributing

Thank you for considering contributing to this stack! I will be updating the guidelines for contributions near soon.

## Security Vulnerabilities

If you discover a security vulnerability within this stack, please send an e-mail to Shine Mon at shine@richkenmedia.com. All security vulnerabilities will be promptly addressed.

### License

This platform is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)
