<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\CreateCompanyRequest;
use App\Http\Requests\UpdateCompanyRequest;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Company;
use Input;
use Session;
class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $company = Company::paginate(5);
        return view('company.index', compact('company'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
         return view('company.create');
    }
    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateCompanyRequest $request)
    {
        //
        $company                      = new Company();
        $company->company_name        = $request->company_name;
        $company->company_description = $request->company_description;
        $company->company_address     = $request->company_address;
        $company->pincode             = $request->pincode;
        $company->phone               = $request->phone;
        $company->email               = $request->email;
        $company->website             = $request->website;
        $company->contact_person      = $request->contact_person;

        if($request->hasFile('logo_image')) {

            $file = Input::file('logo_image');
            //getting timestamp

            $name = $file->getClientOriginalName();

            $file->move(public_path().'/company_logo_upload/', $name);
            $company->logo_image  = $request->file('logo_image')->getClientOriginalName();
        }
        
        $company->save();

        Session::flash('success', 'Created Successfully!!');

        return redirect('admin/company');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        $company = Company::find($id);
        return view('company.show', compact('company'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $company = Company::findorFail($id);
        return view('company.edit', compact('company'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCompanyRequest $request, $id)
    {
        //
     
        $company                          = Company::find($id);
        $company->company_name            = $request->company_name;
        $company->company_description     = $request->company_description;
        $company->company_address         = $request->company_address;
        $company->pincode                 = $request->pincode;
        $company->phone                   = $request->phone;
        $company->email                   = $request->email;
        $company->website                 = $request->website;
        $company->contact_person          = $request->contact_person;

         if($request->hasFile('logo_image')) {

            $file = Input::file('logo_image');
            
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/company_logo_upload/', $name);
    
        $company->logo_image  = $request->file('logo_image')->getClientOriginalName();
    }
        $company->save();
        Session::flash('success', 'Updated Successfully!!');
        return redirect('admin/company')->withInput();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $company = Company::find($id);
        $company->delete();
        Session::flash('success', 'Deleted Successfully!!');
        return back();
    }

    public function aboutCompany($id)
    {
        $company = Company::find($id);
        return view('company.aboutus', compact('company'));

    }
}
