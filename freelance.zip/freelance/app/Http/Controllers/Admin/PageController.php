<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Page;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($slug)
    {
       
        $page_detail = Page::where('slug', $slug)
                        ->get(array('title', 'description','id'))
                        ->first();
     
        return view('page/edit',compact('page_detail'));
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $slug)
    {
        //
       $title = $request->title;
       $description  =  $request->description;
       $page_details =  Page::where('slug',$slug)
                        ->update(array('title'=>$title,'description'=>$description));
         return Redirect::back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
  
}
