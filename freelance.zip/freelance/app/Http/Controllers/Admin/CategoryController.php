<?php

namespace app\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\CreateCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use App\Http\Controllers\Controller;
use App\Category;
use App\Skill;
use Session;
use Input;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $category = Category::paginate(5);
        return view('category.index', compact('category'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('category.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(CreateCategoryRequest $request)
    {
        //
        $category = new Category();

        $category->category_name = $request->categoryname;

        if($request->hasFile('icon_image')) {

            $file = Input::file('icon_image');
            //getting timestamp
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/category_icon_upload/', $name);
            $category->category_icon_image = $request->file('icon_image')->getClientOriginalName();
        }

        if($request->hasFile('c_image')) {

            $file = Input::file('c_image');
            //getting timestamp
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/category_image_upload/', $name);
            $category->category_image = $request->file('c_image')->getClientOriginalName();
        }

        $category->save();
        Session::flash('success', 'Created Successfully!!');
        return redirect('admin/category');
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {	
		$category = Category::find($id);
        return view('category.show', compact('category'));
  
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$category = Category::findorFail($id);
        return view('category.edit', compact('category'));
               
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCategoryRequest $request, $id)
    {
        //
		$category                          = Category::find($id);
        $category->category_name           = $request->categoryname;
         if($request->hasFile('icon_image')) {

            $file = Input::file('icon_image');
            //getting timestamp
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/category_icon_upload/', $name);

             $category->category_icon_image  = $request->file('icon_image')->getClientOriginalName();
        }

        if($request->hasFile('c_image')) {

            $file = Input::file('c_image');
            //getting timestamp
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/category_image_upload/', $name);

             $category->category_image       = $request->file('c_image')->getClientOriginalName();
        }
        $category->save();
        Session::flash('success', 'Updated Successfully!!');
        return redirect('admin/category')->withInput();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
		$Category = Category::find($id);
        $Category->delete();
        Session::flash('success', 'Deleted Successfully!!');
        return back();
    }
	public function deleteAll(Request $request)
    {

        $all_params = $request->all();
        foreach ($all_params['ids'] as $id) :
            $Category = Category::find($id);
            $Category->delete();
        endforeach;
        Session::flash('success', 'Deleted Successfully!!');
        return 'true';
    }


}