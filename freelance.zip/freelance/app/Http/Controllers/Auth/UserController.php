<?php

namespace app\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Category;
use App\Company;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\CompanyRegisterRequest;
use Session;
use Input;
use Redirect;
use View;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::paginate(5);

        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
         return view('users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function showHomePage()
    {
        $category_count  = Category::count();
        $category_count = round($category_count/2);

        $first_category  = Category::take($category_count)->get();
        $second_category = Category::take($category_count)->skip($category_count)->get();
        $company_logos   = Company::all();
        return \View::make('frontend',compact('first_category','second_category','company_logos'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find($id);

        return view('users.edit', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUserRequest $request, $id)
    {
        $user = User::find($id);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = $request->password;
        if ($user->save()) {
            Session::flash('success', 'Created Successfully!!');

            return redirect('admin/users');
        } else {
            Session::flash('errors', 'Sorry, something went wrong!');

            return redirect('admin/users')->withErros();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function freelancerLogin(Request $request)
    {

       $login_details = ['email' => $request->email, 
                        'password' => $request->password
                        ];
        
        $search_user = User::where($login_details)
                        ->get();

        $count_user =count($search_user);

        if($count_user<0)
        {      
            return Redirect::back()->with('login_error', 'user already exist');
        }
        else
        {
            return redirect('freelancer/signup');
        }

    }

    public function freelancerSignup(CreateUserRequest $request)
    {
        $user = new User();
        $user->first_name = $request->first_name;
        $user->last_name  = $request->last_name;
        $user->name       = $request->first_name;
        $user->email      = $request->email;
        $user->password   = $request->password;
        $user->mobile     = $request->mobile;
        if($request->hasFile('photo')) {

            $file = Input::file('photo');
            //getting timestamp
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/profile_image_upload/', $name);
             $user->photo = $request->file('photo')->getClientOriginalName();
        }

       
        if ($user->save()) {
            Session::flash('success', 'Created Successfully!!');

            return redirect('/');
        } else {
            Session::flash('errors', 'Sorry, something went wrong!');

            return redirect('freelancer/signup')->withErrors();
        }
    }

   public function companyRegister(CompanyRegisterRequest $request)
   {
        $company = new Company();
        $company->company_name        = $request->company_name;
        $company->company_description = $request->about_company;
        $company->company_address     = $request->address;
        $company->phone               = $request->phone;
        $company->email               = $request->email;
        $company->website             = $request->website;
        $company->contact_person      = $request->contact_person;
        $company->logo_image          = $request->logo_image;
        $company->pincode             = $request->pincode;
        $company->profile_image       = $request->profile_image;
       
        if($request->hasFile('profile_image')) {

            $file = Input::file('profile_image');
            //getting timestamp
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/profile_image_upload/', $name);
            $company->profile_image = $request->file('profile_image')->getClientOriginalName();
        }
        if($request->hasFile('logo_image')) {

            $file = Input::file('logo_image');
            //getting timestamp
            $name = $file->getClientOriginalName();

            $file->move(public_path().'/company_logo_upload/', $name);
             $company->logo_image  = $request->file('logo_image')->getClientOriginalName();
        }

        if ($company->save()) {
            Session::flash('success', 'Created Successfully!!');

            return redirect('/');
        } else {
            Session::flash('errors', 'Sorry, something went wrong!');

            return redirect('freelancer/signup')->withErrors();
        }

       
   }
}
