<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
//Front end page routes

use App\Category;
use App\Company;
use App\Page;

//home page category listing & logo listing


Route::get('/', [
            'as' => 'user',
            'uses' => 'Auth\UserController@showHomePage'
    ]);

//search filter in home page
Route::post('/', function() {
    $search_keyword  = ltrim(Input::get('search_skills'));  
    $company_search  = Company::where('company_name', 'LIKE', '%' . $search_keyword . '%')->get();  
    $category_search = Category::where('category_name', 'LIKE', '%' . $search_keyword . '%')->get();
    return view('search',compact('company_search','category_search'));                    
});

//About Company Page
Route::get('about/{id}', [ 
            'as' => 'company',
            'uses' => 'Admin\CompanyController@aboutCompany'
]);

//Aboutus and Chairman Message

Route::get('{slug}', function($slug) {

    if($slug=="aboutus")
    {
        $about=Page::where('slug',$slug)->get(array('title', 'description','id'))->first();
        return view('about-us',compact('about')); 
    }   
    else
    {
        $chairmanmessage=Page::where('slug',$slug)->get(array('title', 'description','id'))->first();  
        return view('chairman-message',compact('chairmanmessage')); 
    }
});

//Freelancer Login,Register
Route::get('freelancer/signup', function() {
   return view('freelancer/index');     
});

Route::get('freelancer/forgot-password', function() {
   return view('freelancer/forgot-password');     
});

Route::post('freelancer/forgot-password', [ 
            'as' => 'freelance_login',
            'uses' => 'Auth\UserController@forgotPassword'
]);

Route::post('freelancer/login', [ 
            'as' => 'company',
            'uses' => 'Auth\UserController@freelancerLogin'
]);

Route::post('freelancer/signup', [ 
            'as' => 'company',
            'uses' => 'Auth\UserController@freelancerSignup'
]);


Route::get('company/register', function() {
   return view('company/register');     
});

Route::post('company/register', [
            'as' => 'company',
            'uses' => 'Auth\UserController@companyRegister'
            ]);

// Authentication routes...
Route::get('auth/login', 'Auth\AuthController@getLogin');
Route::post('auth/login', 'Auth\AuthController@postLogin');
Route::get('auth/logout', 'Auth\AuthController@getLogout');

// Registration routes...
Route::get('auth/register', 'Auth\AuthController@getRegister');
Route::post('auth/register', 'Auth\AuthController@postRegister');

// Password reset link request routes...
Route::get('password/email', 'Auth\PasswordController@getEmail');
Route::post('password/email', 'Auth\PasswordController@postEmail');

// Password reset routes...
Route::get('password/reset/{token}', 'Auth\PasswordController@getReset');
Route::post('password/reset', 'Auth\PasswordController@postReset');

Route::group(['prefix' => 'admin', 'middleware' => 'auth'], function () {
    Route::get('/', function () {
        return view('admin');
    });
    Route::post('roles/delete-all', 'Auth\RoleController@deleteAll');
    Route::resource('roles', 'Auth\RoleController');

    Route::get('users/delete-all', 'UserController@deleteAll');
    Route::resource('users', 'Auth\UserController');

    Route::get('profiles/delete-all', 'Admin\ProfileController@deleteAll');
    Route::resource('profiles', 'Admin\ProfileController');

    Route::get('category/delete-all', 'CategoryController@deleteAll');
    Route::resource('category','Admin\CategoryController');

    Route::resource('company','Admin\CompanyController');

    Route::get('{slug}','Admin\PageController@index');

    Route::post('{slug}','Admin\PageController@update');

});

