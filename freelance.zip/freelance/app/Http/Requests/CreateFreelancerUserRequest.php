<?php

namespace app\Http\Requests;

use App\Http\Requests\Request;

class CreateFreelancerUserRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name'         =>  'required|unique:user,first_name',
            'last_name'          =>  'required|unique:user,last_name',
            'email'              =>  'required|unique:user,email',
            'password'           =>  'required|min:3|confirmed:user,password',
            'mobile'             =>  'required|unique:user,mobile',
            'confirm_password'   =>  'required|min:3|:user,confirm_password',
            'photo'              =>  'required| max:1000',
                
        ];
    }
}
