<?php

namespace app\Http\Requests;

use App\Http\Requests\Request;

class CreateCompanyRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'company_name'       =>  'required|unique:company,company_name',
            'address'            =>  'required|unique:company,company_address',
            'company_description'=>  'required|unique:company,company_description',
            'logo_image'         =>  'required| max:1000',   
            'pincode'            =>  'required|unique:company,pincode',
            'phone'              =>  'required|unique:company,phone',
            'email'              =>  'required|unique:company,email',
            'website'            =>  'required|unique:company,website',
            'contact_person'     =>  'required|unique:company,contact_person',
           
        ];
    }
}
