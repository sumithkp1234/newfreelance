<?php

namespace app\Http\Requests;

use App\Http\Requests\Request;

class CreateUserRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name'         =>  'required|unique:users,first_name',
            'last_name'          =>  'required|unique:users,last_name',
            'email'              =>  'required|unique:users,email',
            'password'           =>  'required|min:3|:users,password',
            'mobile'             =>  'required|unique:users,mobile',
            'confirm_password'   =>  'required|min:3|:users,confirm_password',
            'photo'              =>  'required|max:1000',
           
        ];
    }
}
