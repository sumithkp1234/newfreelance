<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompanyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        $table->increments('id');
        $table->text('company_name');
        $table->text('company_description');
        $table->text('company_address');
        $table->text('company_description');
        $table->text('phone');
        $table->text('email');
        $table->text('website');
        $table->text('contact_person');
        $table->text('logo_image');
        $table->text('pincode');
        $table->timestamps();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::drop('company');
    }
}
