jQuery(document).ready(function($){
	//alert("testing page");
});