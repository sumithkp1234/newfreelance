<div class="row">
	<div class="col-xs-12 col-md-12">
		@if (Session::has('message'))
			<div class='alert alert-warning'>{{ Session::get('message') }}</div>
		@endif
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('categoryname', 'Category Name') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('categoryname', null, array('class' => 'form-control')) !!}
	</div>
</div>

<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('iconimage', 'Choose an Icon image') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		 {!! Form::file('icon_image', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('Categoryimage', 'Choose an Category image') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		 {!! Form::file('c_image', null, array('class' => 'form-control')) !!}
	</div>
</div>