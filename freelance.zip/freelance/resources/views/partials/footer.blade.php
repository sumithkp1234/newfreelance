<div id="footer-strip" class="margin-top-30">
    <div class="container-fluid">
        <div class="col-md-12 text-center">
            <p>Powered by Laravel</p>
        </div>
    </div>
</div>
