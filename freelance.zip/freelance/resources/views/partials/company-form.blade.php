<div class="row">
	<div class="col-xs-12 col-md-12">
		@if (Session::has('message'))
			<div class='alert alert-warning'>{{ Session::get('message') }}</div>
		@endif
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('companyname', 'Company Name') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('company_name', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('address', 'Company Address') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('company_address', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('companydescription', 'Company Description') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::textarea('company_description', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('logo_image', 'Choose an logo image') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		 {!! Form::file('logo_image', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('pincode', 'Pincode') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('pincode', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('phone', 'Phone No') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('phone', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('email', 'Company Email') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('email', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('website', 'Company Website') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('website', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('contact person', 'Contact Person') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('contact_person', null, array('class' => 'form-control')) !!}
	</div>
</div>


							
						