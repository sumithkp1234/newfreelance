
	<div class="login-inner">
		<div class="login-inner-1">
		  	{!! Form::label('first_name', 'Company Name') !!}
			<span>*</span> {!! Form::text('company_name', '')!!}
			<div class="error">
				{{ $errors->first('company_name') }}
			</div>
		</div>
		<div class="login-inner-1">
		  {!! Form::label('address', 'Address') !!}
			<span>*</span>  {!! Form::text('address', '')!!}
			<div class="error">{{ $errors->first('address') }}
		</div>
		</div>
		<div class="login-inner-1">
			{!! Form::label('pincode', 'Pincode') !!} <span>*</span> 
			{!! Form::text('pincode', '')!!}
			<div class="error">{{ $errors->first('pincode') }}
		</div>
		</div>
		<div class="login-inner-1">
		 	{!! Form::label('phone', 'Phone') !!}
			<span>*</span> {!! Form::text('phone','')!!}
			<div class="error">{{ $errors->first('phone') }}
		</div>
		</div>
		<div class="login-inner-1">
			{!! Form::label('email', 'Email') !!} <span>*</span> {!! Form::text('email','') !!}
			<div class="error">{{ $errors->first('email') }}
		</div>
		</div>
		<div class="login-inner-1">
			{!! Form::label('website', 'Website') !!} 
		 	<span>*</span> {!! Form::text('website', '')!!}
		 	<div class="error">{{ $errors->first('website') }}
		</div>
		</div>
		<div class="login-inner-1">
			{!! Form::label('contact-person', 'Contact Person') !!} 
		 	<span>*</span> {!! Form::text('contact_person', '')!!}
		 	<div class="error">{{ $errors->first('contact-person') }}
		</div>
		</div>
		<div class="login-inner-1">
			{!! Form::label('aboutcompany', 'About the company (max: 200 words) ') !!} 
		 	<span>*</span> {!! Form::textarea('about_company', '')!!}
		 	<div class="error">{{ $errors->first('aboutcompany') }}
		</div>
		</div>
		<div class="login-inner-1">
			{!! Form::label('company_image', 'Upload Company Logo') !!} <span>*</span>  
			{!! Form::file('logo_image', '')!!}
			<div class="error">{{ $errors->first('comp_image') }}
		</div>
		</div>
		<div class="login-inner-1">
			{!! Form::label('profile_image', 'Upload Profile Photo') !!} <span>*</span>  {!! Form::file('profile_image', '')!!}
			<div class="error">{{ $errors->first('profile_image') }}
		</div>
		</div>
		<div class="login-btn">
		
			{!! Form::checkbox('Terms & Conditions') !!}
			    Terms & Conditions
									
		   {!! Form::submit('Pay Online & Register',['class' => 'button'])!!} 
		 <div class="error">{{ $errors->first('Terms & Conditions') }}</div>
		</div>
	</div>
