<div class="row">
	<div class="col-xs-12 col-md-12">
		@if (Session::has('message'))
			<div class='alert alert-warning'>{{ Session::get('message') }}</div>
		@endif
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('title', 'Title') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::text('title', null, array('class' => 'form-control')) !!}
	</div>
</div>
<div class="form-group row">
	<div class="col-xs-12 col-md-2">
		{!! Form::label('description', 'Description') !!}
	</div>
	<div class="col-xs-12 col-md-10">
		{!! Form::textarea('desription', null, array('class' => 'form-control')) !!}
	</div>
</div>