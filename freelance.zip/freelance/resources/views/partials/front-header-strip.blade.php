<header class="freelance-header">
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="logo-freelance">
					<a href="/"><img src="../images/logo.png"/></a>
					</div>
				</div>
		
				<div class="col-md-9">
					<div class="social-icons-free">
						<ul>
							<li><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="https://twitter.com/?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="https://plus.google.com"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="https://in.linkedin.com"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<div id="flip">Navigation<span><i class="fa fa-bars" aria-hidden="true"></i></span></div>
					<div class="menu-freelance">
						<div id="panel">
							<ul>
								<li><a href="/">Home </a></li>
								<li><a href="/aboutus">About Us </a></li>
								<li><a href="/chairmanmessage">Chairman’s Message </a></li>
								<li><a href="/freelancer/signup">Freelancer Log in  </a></li>
								<li><a href="">Annual Forum</a></li>
							</ul>
						</div>
						<div class="dropdown">   
							<div id="google_translate_element"></div>
							<script type="text/javascript">
								function googleTranslateElementInit() {
								 new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
								}
							</script>
							<script type="text/javascript" src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>