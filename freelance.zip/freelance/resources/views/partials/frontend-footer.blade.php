<footer class="freelancefoo">
	<div class="container">
			<div class="row">
				<div class="col-md-3 col-xs-12 col-sm-4">
					<h3>all-freelancers</h3>
					<div class="links">
						<ul>
							<li><a href="{{URL::to('/company/register')}}"><i class="fa fa-angle-right" aria-hidden="true"></i> List & Advertise Your Company</a></li>
							<li><a href=""><i class="fa fa-angle-right" aria-hidden="true"></i> Business News</a></li>
							<li><a href=""><i class="fa fa-angle-right" aria-hidden="true"></i> Terms</a></li>
							<li><a href=""><i class="fa fa-angle-right" aria-hidden="true"></i> Privacy Policy</a></li>
							<li><a href=""><i class="fa fa-angle-right" aria-hidden="true"></i> FAQs</a></li>
						</ul>
					</div>
				</div>
	
				<div class="col-md-2 col-xs-12 col-sm-4">
					<h3>Follow Us</h3>
					<div class="socila-links">
						<ul>
							<li><a href="https://www.google.co.in/"><span><i class="fa fa-google" aria-hidden="true"></i></span> Google</a></li>
							<li><a href="https://in.pinterest.com/"><span><i class="fa fa-pinterest-p" aria-hidden="true"></i></span> Pinterest </a></li>
							<li><a href="https://www.facebook.com"><span><i class="fa fa-facebook" aria-hidden="true"></i></span> Facebook</a></li>
							<li><a href="https://twitter.com/?lang=en"><span><i class="fa fa-twitter" aria-hidden="true"></i></span> Twitter</a></li>
							<li><a href="https://in.linkedin.com/"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span> Linkedin </a></li>
							<li><a href="https://www.rss.com/"><span><i class="fa fa-rss" aria-hidden="true"></i></span> RSS</a></li>
						</ul>
					</div>
				</div>
	
				<div class="col-md-2 col-xs-12 col-sm-4">
					<div class="newsletter">
						<img src="../images/newsletter.png"/>
						<input type="text" placeholder="Enter your email id"></input>
						<button>subscribe</button>
					</div>
				</div>
				<div class="col-md-3 col-xs-12 col-sm-8">
					<div class="respo-free">
						<iframe src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FBluedawg-Design%2F70870858258&amp;width=250&amp;height=200&amp;colorscheme=light&amp;show_faces=true&amp;border_color&amp;stream=true&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:200px;" allowTransparency="true"></iframe>
					</div>
				</div>
	
				<div class="col-md-2 col-xs-12 col-sm-4">
					<div class="contact">
						<h3>Contact</h3>
						<address>
						<p>support@all-freelancers.com<br>
						info@all-freelancers.com<br><br>
						or 971 56 612 8835<br>
						www.all-freelancers.com</p>
						</address>
					</div>
				</div>
			</div>
	
			<div class="row endfooter">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-xs-12 col-sm-3">
							<div class=" resp">
								<a href=""><img class="text-center" src="../images/footerimg.png"/></a>
							</div>
						</div>
						<div class="col-md-2 col-xs-12 col-sm-3">
							<div class="freel123 resp">
								<a class="text-left" href="https://www.skype.com/en/"><div class="btn-footer">
								<span><img src="../images/skype.png"/></span> Skype Us
							</div></a>
							</div>
						</div>
					
						<div class="col-md-2 col-xs-12 col-sm-3">
							<div class="text-center resp">
								<a class="text-left" href="https://www.messenger.com/"><div class="btn-footer">
								<span><img src="../images/messenger2.png"/></span> Message Us
								</div></a>
							</div>
						</div>
					
						<div class="col-md-3 col-xs-12 col-sm-3">
							<div class="text-center resp">
								<a class="text-left" href=""><div class="btn-footer">
								<span><img src="../images/btn-icon.png"/></span> Contact Us
								</div></a>
							</div>
						</div>
					
						<div class="col-md-2 col-xs-12 col-sm-12">
							<div class="text-right resp">
								<a class="text-left" href=""><div class="btn-footer">
								<span><img src="../images/btn-icon1.png"/></span> Leave a message
								</div></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
</footer>
	
	<footer class="endfree">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-sm-8">
					<div class="end-footer1">
						<ul>
							<li><a href="">Privacy Policy</a></li>
							<li><a href="">Terms & Conditions </a></li>
							<li><a href="">Disclaimer</a></li>
							<li><a href="">Downloads </a></li>
							<li><a href="">FAQs </a></li>
							<li><a href="">Legal</a></li>
							<li><a href="">Bulletin</a></li>
							<li><a href="">Careers</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="text-right respomi">
						<a href="">Copyright 2016 all-freelancers.com</a>
					</div>
				</div>
			</div>
		</div>
	</footer>

   <script>
	  $(document).ready(function() {

	  $("#owl-demo").owlCarousel({

	    autoPlay: 3000, //Set AutoPlay to 3 seconds

	    items: 4,
	    itemsDesktop: [1199, 3],
	    itemsDesktopSmall: [979, 3]

	  });
	});
    </script>
    <script>
	    function myFunction()
	    {
	    document.getElementById("myDropdown").classList.toggle("show");
		}
	</script>