@extends('admin')

@section('title', 'Role List')

@section('page-content')
	<div class="col-xs-12">
		<div id="content-wrapper" class="container">
			<section class="col-sm-12">
				<div class="section-header">
					<h1>Role List</h1><br>
				</div>
				<a id="btn_style" href="{{url('admin/roles/create')}}" class='btn btn-primary btn-sm'>Create New Role</a>
			</section>
			<!-- error or success message -->
			<div class="row">
				<div class="col-xs-12 col-md-12">
					@if (count($errors) > 0)
						<div class="alert alert-danger">
							@foreach ($errors->all() as $error)
								<p>{{ $error }}</p>
							@endforeach
						</div>
					@endif
					<div id="success">
						@if (Session::has('success'))
							<div class='alert alert-success'>{{ Session::get('success') }}</div>
						@endif
					</div>
				</div>
			</div>
			<section class="col-xs-12 table-responsive">
				<div class="panel panel-default row">
					<!-- Table -->
					<table class="table table-striped table-bordered">
						<!-- start if here -->
						@if(count($role)>0)
							<tr>
								<th class="text-center">
									<label id="select_all">
										{!! Form::checkbox('check_all_roles', 'value', null, ['id' => 'check_all_roles'])!!}
										SELECT ALL
									</label>
								</th>
								<th class="text-center">Name</th>
								<th class="text-center">Description</th>
								<th></th>
							</tr>
							<!-- Started Loop for fetching records from DB (for loop) -->
							@foreach($role as $data => $value)
							<tr>
								<td class="text-center">
									<!-- checkbox to each group (to select the purticular records -->
									{!! Form::checkbox('roles_list[]', $value->id, null, ['class' => 'roles_list'])!!}
								</td>
								<td>{{ $value->name }}</td>
								<td>{{ $value->description }}</td>

								<!-- we will also add show, edit, and delete buttons -->
								<td>
									<a class="btn btn-small btn-primary btn-sm" href="{{ URL::to('admin/roles/'.$value->id) }}" style="float: left;">Show</a>

									<a class="btn btn-small btn-info btn-sm" href="{{ URL::to('admin/roles/'.$value->id.'/edit') }}" style="float: left;">Edit</a>

									{!! Form::open(array('class' => 'inline_form','method'=>'DELETE','style' => 'float: left','url' =>'admin/roles/'.$value->id)) !!}
										{!! Form::submit('Delete', array('class' => 'btn btn-small btn-warning btn-sm')) !!}
									{!!  Form::close() !!}
								</td>
							</tr>
							@endforeach
							<!-- endfor loop -->
							<tr>
								<td colspan="4">
									<input type="hidden" name="_token" value="{{ csrf_token() }}">
									{!! Form::submit('Delete All', array('class' => 'btn btn-small btn-warning btn-sm', 'id' => 'delete_all')) !!}
								</td>
							</tr>
						@else<!-- else if here -->
						<!-- put a tr with a message called "Sorry no records found!" -->
							<tr><h4 class="text-center">"Sorry no records found!"</h4></tr>
						@endif<!-- end if here -->
					</table>
				</div>
			</section>
		</div>
	</div>
@endsection
@section('footer')
@parent
<script src="{{ url('js/groups/index.js') }}"></script>
<script type="text/javascript">
	jQuery(document).ready(function($){ 
	    $("#check_all_roles").change(function(){
	      	$(".roles_list").prop('checked', $(this).prop("checked"));
	    });
		$('#delete_all').click(function(){  
			var selected_value = [];
		    $(".roles_list:checked").each(function(){
		        selected_value.push($(this).val());
		    });
    		$.ajax({
		      url: 'roles/delete-all',
		      type: "post",
		      data: {'ids':selected_value, '_token': $('input[name=_token]').val()},
		      success: function(data){
		        	url = {!! json_encode(url('admin/roles')) !!};
		        	$( "#success" ).html( "<div class='alert alert-success'>Record Deleted</div>" );
		        	setTimeout( function(){ 
					    $(location).attr("href", url);
					}  , 2000 );	
		      }
		    });
    	});
	});
</script>

@endsection