@extends('frontend-master')

@section('title', 'Sign Up')

@section('page-content')
	<section class="sign-up">
		<div class="container">
			<div class="row">
				<div class="sign-up-content">
					<div class="col-md-12"><h3>Login</h3></div>
						@if(\Session::has('login_error'))
	  					 		 <div class="alert-box err">
	      							<span>{!! Session::get('login_error') !!}</span>
								</div>
						@endif
						  {!! Form::open(array('url' => 'freelancer/login', 'method' => 'POST')) !!}
						<div class="col-md-6">
							<div class="login">
								<p>Login Here if  You are already registered.<br><br>
								<span>Login with your e mail address and password.</span>
								</p>
		
								<div class="login-inner">
									<div class="login-inner-1">
										{!! Form::label('login', 'Login Name') !!} <span>*</span>
										{!! Form::text('email1', old('login', '')) !!}
										<div class="error">
											{{ $errors->first('email1') }}
										</div>
									</div>

							
									<div class="login-inner-1">
										{!! Form::label('password', 'Password') !!}
										<span>*</span> 
										{!! Form::password('password1','') !!}
										<div class="error">
											{{ $errors->first('password1') }}
										</div>
									</div>
									
									<div class="login-btn">
									 	{!! Form::submit('Login','') !!}
									</div>
								
									<p>Forgot your password? <a href="/freelancer/forgot-password">Click here</a> to reset.</p>
								</div>
								{!! Form::close() !!}
								
							</div>
						</div>
		
						<div class="col-md-6">
							<div class="signup">
								<p>Sign-up<br><br>
								<span>Not yet registered? Sign-up now!!</span>
								</p>
								 {!! Form::open(array('url' => 'freelancer/signup', 'method' => 'POST','files'=>'true')) !!}
								<div class="login-inner">
									<div class="login-inner-1">
									  	{!! Form::label('first_name', 'First Name') !!}
										<span>*</span> {!! Form::text('first_name', '')!!}
										<div class="error">
											{{ $errors->first('first_name') }}
										</div>
									</div>
									<div class="login-inner-1">
									  {!! Form::label('last_name', 'Last Name ') !!}
										<span>*</span>  {!! Form::text('last_name', '')!!}
										<div class="error">{{ $errors->first('last_name') }}
									</div>
									</div>
									<div class="login-inner-1">
										{!! Form::label('username', 'Username') !!} <span>*</span> 
										{!! Form::text('email', '')!!}
										<div class="error">{{ $errors->first('email') }}
									</div>
									</div>
									<div class="login-inner-1">
									 	{!! Form::label('password', 'Password') !!}
										<span>*</span> {!! Form::password('password','')!!}
										<div class="error">{{ $errors->first('password') }}
									</div>
									</div>
									<div class="login-inner-1">
										{!! Form::label('password_confirmation', 'Confirm Password') !!} <span>*</span> {!! Form::password('confirm_password','') !!}
										<div class="error">{{ $errors->first('confirm_password') }}
									</div>
									</div>
									<div class="login-inner-1">
										{!! Form::label('mobile', 'Mobile') !!} 
									 	<span>*</span> {!! Form::text('mobile', '')!!}
									 	<div class="error">{{ $errors->first('mobile') }}
									</div>
									</div>
									<div class="login-inner-1">
										{!! Form::label('photo', 'Upload Profile Photo') !!} <span>*</span>  {!! Form::file('photo', '')!!}
										<div class="error">{{ $errors->first('photo') }}
									</div>
									</div>
									<div class="login-btn">
									
										{!! Form::checkbox('Terms & Conditions') !!}
										    Terms & Conditions
																
									   {!! Form::submit('Pay Online & Register',['class' => 'button'])!!} 
									 <div class="error">{{ $errors->first('Terms & Conditions') }}</div>
									</div>
								</div>
								{!! Form::close() !!}
							</div>
						</div>					
				</div>
			</div>
		</div>
	</section>
@endsection