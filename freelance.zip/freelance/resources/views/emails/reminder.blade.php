<body>
A request has recently been made to change your password.

{!! link_to_route('reminders.edit', 'Reset your password now', ['id' => $id, 'code' => $code]) !!}
 
 <br/>
</body>