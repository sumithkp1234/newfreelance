@extends('frontend-master')

@section('title', 'Home')

@section('page-content')
	<section class="main-content resp-mb">
		<div class="container">
			<div class="row">
				<div class="demo">
					
					<div class="item">
						<ul id="content-slider" class="content-slider">
							@foreach($first_category as $item => $category_details1)
							 <li class="col-xs-12 col-md-3 col-sm-3">
								<div class="respmon thumbnail thumbnail12">
									<div class="round-freelance back-fiamge">
											<img class="frl-l" src="category_image_upload/{{$category_details1->category_image}}"/>	
										<div class="center">
											<div class="sub-round">
												<img src="category_icon_upload/{{$category_details1->category_icon_image}}"/>
											</div>
										</div>
									</div>
									<div class="main-btn-free">
										<a href="">{{$category_details1->category_name}}</a>
									</div>
								</div>
							</li>
							@endforeach
						</ul>
					</div>
					
				</div>
			</div>
		</div>
	</section>

	<section class="search-freelance resp-mb">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="search-form">
						 {!! Form::open(array('url' => '/', 'method'=>'post')) !!}
						 {!! Form::text('search_skills', null, array('placeholder'=>'Search Keywords, Freelancers, Companies, Categories, State, Countries and More')) !!}
							
						{!! Form::submit('SEARCH',  array('class' => 'btn')) !!}
							
						{!! Form::close() !!}
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="main-content resp-mb">
		<div class="container">
			<div class="row">
				<div class="demo" style="width:100%">
					<div class="item">
						<ul id="content-slider1" class="content-slider">
							@foreach($second_category as $item1 => $category_details2)
						 		<li class="col-xs-12 col-md-3 col-sm-3">
									<div class="respmon thumbnail thumbnail12">
										<div class="round-freelance back-fiamge4">
											<img class="frl-l" src="category_image_upload/{{$category_details2->category_image}}"/>	
											<div class="center">
												<div class="sub-round">
													<img src="category_icon_upload/{{$category_details2->category_icon_image}}"/>
												</div>
											</div>
										</div>
										<div class="main-btn-free">
											<a href="">{{$category_details2->category_name}}</a>
										</div>
									</div>
								</li>
							@endforeach
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="main-content resp-mb1">
		<div class="container">
			<div class="row">
				<div class="demo">
					
					<div class="item">
						<ul id="content-slider3" class="content-slider">
							@foreach($first_category as $item => $category_details1)
							 <li class="col-xs-12 col-md-3 col-sm-3">
								<div class="respmon thumbnail thumbnail12">
									<div class="round-freelance back-fiamge">
											<img class="frl-l" src="category_image_upload/{{$category_details1->category_image}}"/>	
										<div class="center">
											<div class="sub-round">
												<img src="category_icon_upload/{{$category_details1->category_icon_image}}"/>
											</div>
										</div>
									</div>
									<div class="main-btn-free">
										<a href="">{{$category_details1->category_name}}</a>
									</div>
								</div>
							</li>
							@endforeach
						</ul>
					</div>
					
				</div>
			</div>
		</div>
	</section>

	<section class="search-freelance resp-mb1">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="search-form">
						 {!! Form::open(array('url' => '/', 'method'=>'post')) !!}
						 {!! Form::text('search_skills', null, array('placeholder'=>'Search Keywords, Freelancers, Companies, Categories, State, Countries and More')) !!}
							
						{!! Form::submit('SEARCH',  array('class' => 'btn')) !!}
							
						{!! Form::close() !!}
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="main-content resp-mb1">
		<div class="container">
			<div class="row">
				<div class="demo" style="width:100%">
					<div class="item">
						<ul id="content-slider4" class="content-slider">
							@foreach($second_category as $item1 => $category_details2)
						 		<li class="col-xs-12 col-md-3 col-sm-3">
									<div class="respmon thumbnail thumbnail12">
										<div class="round-freelance back-fiamge4">
											<img class="frl-l" src="category_image_upload/{{$category_details2->category_image}}"/>	
											<div class="center">
												<div class="sub-round">
													<img src="category_icon_upload/{{$category_details2->category_icon_image}}"/>
												</div>
											</div>
										</div>
										<div class="main-btn-free">
											<a href="">{{$category_details2->category_name}}</a>
										</div>
									</div>
								</li>
							@endforeach
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="main-content resp-mb2">
		<div class="container">
			<div class="row">
				<div class="demo">
					
					<div class="item">
						<ul id="content-slider5" class="content-slider">
							@foreach($first_category as $item => $category_details1)
							 <li class="col-xs-12 col-md-3 col-sm-3">
								<div class="respmon thumbnail thumbnail12">
									<div class="round-freelance back-fiamge">
											<img class="frl-l" src="category_image_upload/{{$category_details1->category_image}}"/>	
										<div class="center">
											<div class="sub-round">
												<img src="category_icon_upload/{{$category_details1->category_icon_image}}"/>
											</div>
										</div>
									</div>
									<div class="main-btn-free">
										<a href="">{{$category_details1->category_name}}</a>
									</div>
								</div>
							</li>
							@endforeach
						</ul>
					</div>
					
				</div>
			</div>
		</div>
	</section>

	<section class="search-freelance resp-mb2">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="search-form">
						 {!! Form::open(array('url' => '/', 'method'=>'post')) !!}
						 {!! Form::text('search_skills', null, array('placeholder'=>'Search Keywords, Freelancers, Companies, Categories, State, Countries and More')) !!}
							
						{!! Form::submit('SEARCH',  array('class' => 'btn')) !!}
							
						{!! Form::close() !!}
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="main-content resp-mb2">
		<div class="container">
			<div class="row">
				<div class="demo" style="width:100%">
					<div class="item">
						<ul id="content-slider6" class="content-slider">
							@foreach($second_category as $item1 => $category_details2)
						 		<li class="col-xs-12 col-md-3 col-sm-3">
									<div class="respmon thumbnail thumbnail12">
										<div class="round-freelance back-fiamge4">
											<img class="frl-l" src="category_image_upload/{{$category_details2->category_image}}"/>	
											<div class="center">
												<div class="sub-round">
													<img src="category_icon_upload/{{$category_details2->category_icon_image}}"/>
												</div>
											</div>
										</div>
										<div class="main-btn-free">
											<a href="">{{$category_details2->category_name}}</a>
										</div>
									</div>
								</li>
							@endforeach
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="image-slider-free">
	<div class="container">
		<div class="col-md-12">
	        <div class="tophead"><h3><em>Enlisted companies and top brands</em></h3></div>
			
	       	 	<div class="brd-free">
	    			<div id="owl-demo">
							 
						@foreach($company_logos as $result => $company)
					 		<div class="owl-item grayscale">
								
								<a href="{{ URL::to('about/'.$company->id) }}" title="Home Page">
									<img class="frl-l" src="company_logo_upload/{{$company->logo_image}}"/>	
								</a>
							</div>
									
								
						@endforeach
							
					</div>
				</div>
      
  			</div>
        </div>
	</div>                         
</div><!-- /#myCarousel -->
        
</div><!-- /.span12 -->          
</div><!-- /.row --> 
</div><!-- /.container -->
</section>
@endsection