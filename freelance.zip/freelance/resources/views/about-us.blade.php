@extends('frontend-master')

@section('title', 'About Us')

@section('page-content')

<section class="sign-up">
	<div class="container">
		<div class="row">
			<div class="sign-up-content11">
				<div class="col-md-12">
					<div class="signup">
						<h2>{{$about->title}}</h2><br>
						<p>{{$about->description}}</p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
		
@endsection