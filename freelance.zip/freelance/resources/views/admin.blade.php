@extends('master')

@section('title', 'Admin Area')

@include('partials.admin-header-strip')

@section('page-content')

    
@endsection