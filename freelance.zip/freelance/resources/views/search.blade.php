@extends('frontend-master')

@section('title', 'Frontend Area')

@section('page-content')
	<section class="main-content">
		<div class="container">
			<div class="row">
				<div class="demo">
				
					@foreach($category_search as $item => $cat_search)
						<table>
							<tr>
								{{$cat_search->category_name}}			

							</tr>
						</table>
					@endforeach
					@foreach($company_search as $item1 => $comp_search)
						<table>
							<tr>
								{{$comp_search->company_name}}		

							</tr>
						</table>
					@endforeach
				</div>
			</div>
		</div>
	</section>
@endsection