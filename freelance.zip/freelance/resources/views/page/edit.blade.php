@extends('admin')

@section('title', 'Update Pages')

@section('page-content')
    <div class="col-xs-12">
        <div id="content-wrapper" class="container">
            <div class="row">
                <div class="col-xs-12 col-md-12">
                    <div class="section-header">
                        <h1>Update Pages</h1></br>
                    </div>
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            @foreach ($errors->all() as $error)
                                <p>{{ $error }}</p>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
            <div id="success" class="col-xs-12 col-md-12">
                @if (Session::has('success'))
                    <div class='alert alert-success'>{{ Session::get('success') }}</div>
                @endif
            </div>
            {!! Form::model(array('url' => 'admin/'.$page_detail->id, 'method'=>'post')) !!}
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        @if (Session::has('message'))
                            <div class='alert alert-warning'>{{ Session::get('message') }}</div>
                        @endif
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-xs-12 col-md-2">
                        {!! Form::label('title', 'Title') !!}
                    </div>
                    <div class="col-xs-12 col-md-10">
                        {!! Form::text('title', $page_detail->title, array('class' => 'form-control')) !!}
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-xs-12 col-md-2">
                        {!! Form::label('description', 'Description') !!}
                    </div>
                    <div class="col-xs-12 col-md-10">
                        {!! Form::textarea('description', $page_detail->description, array('class' => 'form-control')) !!}
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-xs-12 text-right">
                        {!! Form::submit('UPDATE', array('class' => 'btn btn-primary btn-sm')) !!}
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
@endsection