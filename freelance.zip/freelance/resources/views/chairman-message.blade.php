@extends('frontend-master')

@section('title', 'Chairman Message')

@section('page-content')

<section class="sign-up">
	<div class="container">
		<div class="row">
			<div class="sign-up-content11">
				<div class="col-md-12 signup">
					
						<h2>{{$chairmanmessage->title}}</h2><br>
					
						<div class="col-md-3">
							<img src="images/chairman.jpg" width="250" height="288">
						</div>
						<div class="col-md-9">
							<p>{{$chairmanmessage->description}}</p>
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
		
@endsection