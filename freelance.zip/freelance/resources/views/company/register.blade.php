@extends('frontend-master')

@section('title', 'Create Company')

@section('page-content')
    <section class="sign-up">
		<div class="container">
			<div class="row">
				<div class="sign-up-content11">
		
					<div class="col-md-12">
			            <div class="signup">
							<h2>Register and Upload your data<br>
				            <span>Please fill the following form and sign up to our portal</span>
				           </h2>
			
	          				  {!! Form::open(array('url' => 'company/register', 'method'=>'post', 'files'=> true)) !!}
	               				 @include('partials.company-registration')
	              
	            				{!! Form::close() !!}
        				</div>
   					 </div>
               </div>
         </div>
    </div>
    </section>
@endsection