
@extends('frontend-master')

@section('title', 'About Us')

@section('page-content')
	<section class="company-page">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-4">
					<div class="company-page-left">

						<img src="../company_logo_upload/{{$company->logo_image}}" width="60" height="68"/>
						<address>
							<p>
							<span>Company Name:</span><br>
							{{$company->company_name}}<br><br>
							<span>Address:</span><br>
							{{$company->company_address}}<br><br>
							<span>Pincode:</span><br>
							{{$company->pincode}}<br><br>
							<span>Phone:</span><br>
							{{$company->phone}}<br><br>
							<span>Email:</span><br>
							{{$company->email}}<br><br>
							<span>Website:</span><br>
							{{$company->website}}<br><br>
							<span>Contact Person:</span><br>
							{{$company->contact_person}}
							</p>
						</address>
						<div class="btn-company">
							<button>Enquiry</button>
						</div>
					</div>
				</div>
				<div class="col-md-9 col-sm-8">
					<div class="about-company">
						<img src="../images/company1.jpg"/>
						<div class="company-main-content">
							<h3>About the Company</h3>
							<p>{{$company->company_description}}.</p>
						</div>
						<div class="social-icons-free">
							<ul>
								<li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li><a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								<li><a href=""><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
@endsection