@extends('admin')

@section('title', 'Edit company')

@section('page-content')
	<div class="col-xs-12">
		<div id="content-wrapper" class="container">
			<div class="section-header">
			<h1>Edit company</h1>
			</div>
	
			{!! Form::model($company, array('url' => 'admin/company/'.$company->id, 'method' => 'put', 'files'=>'true'))
			!!}
				@include('partials.company-form')
				<div class="form-group row">
					<div class="col-xs-12 text-right">
						{!! Form::submit('UPDATE', array('class' => 'btn btn-primary btn-sm')) !!}
					</div>
				</div>
				
			{!! Form::close() !!}
				
		</div>
	</div>
@endsection