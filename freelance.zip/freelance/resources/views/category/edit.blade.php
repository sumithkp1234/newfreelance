@extends('admin')

@section('title', 'Edit Category')

@section('page-content')
	<div class="col-xs-12">
		<div id="content-wrapper" class="container">
			<div class="section-header">
			<h1>Edit Category</h1>
			</div>
	
			{!! Form::model($category, array('url' => 'admin/category/'.$category->id, 'method' => 'put', 'files'=>'true'))
			!!}
				<div class="row">
					<div class="col-xs-12 col-md-12">
						@if (count($errors) > 0)
							<div class="alert alert-danger">
								@foreach ($errors->all() as $error)
									<p>{{ $error }}</p>
								@endforeach
							</div>
						@endif
					</div>
				</div>
				<div id="success" class="col-xs-12 col-md-12">
					@if (Session::has('success'))
						<div class='alert alert-success'>{{ Session::get('success') }}</div>
					@endif
				</div>
				<div class="form-group row">
					<div class="col-xs-12 col-md-2">
						{!! Form::label('name', 'Category Name') !!}
					</div>
					<div class="col-xs-12 col-md-10">
						{!! Form::text('categoryname', $category->category_name , array('class' => 'form-control', 'autocomplete' => 'off')) !!}
					</div>
				</div>
				
				<div class="form-group row">
					<div class="col-xs-12 col-md-2">
						{!! Form::label('image', 'Choose an Icon image') !!}
					</div>
					<div class="col-xs-12 col-md-10">
						 {!! Form::file('icon_image', null, array('class' => 'form-control')) !!}

					</div>
				</div>
				<div class="form-group row">
					<div class="col-xs-12 col-md-2">
						{!! Form::label('Categoryimage', 'Choose an Category image') !!}
					</div>
					<div class="col-xs-12 col-md-10">
						 {!! Form::file('c_image', null, array('class' => 'form-control')) !!}
					</div>
				</div>
				<div class="form-group row">
					<div class="col-xs-12 text-right">
						{!! Form::submit('UPDATE', array('class' => 'btn btn-primary btn-sm')) !!}
					</div>
				</div>
			{!! Form::close() !!}
				
		</div>
	</div>
@endsection