
<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>@yield('title')</title>
    <!---script--->
    <script type="text/javascript">
    $(document).ready(function(){
     $("#myCarousel").carousel({
         interval : 30
     });
    });
    </script>
    <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/npm.js"></script>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
     <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
     <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="js/lightslider.js"></script>
     <!---CSS---->
     <link href="{!! asset('css/bootstrap.css') !!}" media="all" rel="stylesheet" type="text/css" />
     <link href="{!! asset('bootstrap.min.css') !!}" media="all" rel="stylesheet" type="text/css" />
     <link href="{!! asset('css/bootstrap.css') !!}" media="all" rel="stylesheet" type="text/css" />
     <link href="{!! asset('css/bootstrap-theme.css') !!}" media="all" rel="stylesheet" type="text/css" />
     <link href="{!! asset('css/bootstrap-theme.min.css') !!}" media="all" rel="stylesheet" type="text/css" />
     <link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.2/owl.carousel.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.2/owl.carousel.js"></script>
     <link href="{!! asset('style.css') !!}" media="all" rel="stylesheet" type="text/css" />
     <link href="{!! asset('css/lightslider.css') !!}" media="all" rel="stylesheet" type="text/css" />
      <link href="{!! asset('js/search.js') !!}" media="all" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="{!! asset('css/owl.carousel.css') !!}">
    <link rel="stylesheet" type="text/css" href="{!! asset('css/owl.theme.css') !!}">
  
     <script>

         $(document).ready(function() {
            var timer;
            function up()
            {
                timer= setTimeout(function()
                {
                    var keywords=$('#search_skills').val();
                    alert(keywords);

                },500);
            }

            function down()
            {

            clearTimeout($timer);
            }
            $("#content-slider").lightSlider({
                loop:true,
                keyPress:true
            });
            $("#content-slider1").lightSlider({
                loop:true,
                keyPress:true
            });
            $("#content-slider2").lightSlider({
                loop:true,
                keyPress:true
            });
            $("#content-slider3").lightSlider({
                loop:true,
                keyPress:true,
                item: 1
            });
            $("#content-slider4").lightSlider({
                loop:true,
                keyPress:true,
                item: 1
        
            });
            $("#content-slider5").lightSlider({
                loop:true,
                keyPress:true,
                item: 3
        
            });
            $("#content-slider6").lightSlider({
                loop:true,
                keyPress:true,
                item: 3
        
            });
            $('#image-gallery').lightSlider({
                gallery:true,
                item:1,
                thumbItem:9,
                slideMargin: 0,
                speed:500,
                auto:true,
                loop:true,
                onSliderLoad: function() {
                    $('#image-gallery').removeClass('cS-hidden');
                }  
            });
        });
    </script>
    
    <script>
    $(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
    });
    </script>
     @section('header')
     
    @show
</head>
<body>

    @section('page-header')
        @include('partials.front-header-strip')
    @show
       
    @yield('page-content')
           
    @section('page-footer')
        @include('partials.frontend-footer')
    @show
   
    <!-- all scripts -->
   
    @section('footer')
     
    @show
  </body> 
</html>